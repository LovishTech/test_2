package com.example.demo12;

import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.animation.FadeTransition;
import javafx.animation.ScaleTransition;
import javafx.util.Duration;
import javafx.animation.Timeline;
import javafx.animation.KeyFrame;

public class LoginController {
    @FXML private TextField usernameField;
    @FXML private PasswordField passwordField;

    private int loginAttempts = 0;
    private static final int MAX_ATTEMPTS = 5;

    @FXML
    public void handleLogin() {
        String username = usernameField.getText();
        String password = passwordField.getText();

        if (loginAttempts >= MAX_ATTEMPTS) {
            showAlert("Login Blocked", "Too many failed attempts. The application will now close.");
            Stage stage = (Stage) usernameField.getScene().getWindow();
            stage.close();
            return;
        }

        if ("lovish batra".equals(username) && "lovish28".equals(password)) {
            openDashboard(username);
        } else {
            loginAttempts++;
            showAlert("Login Failed", "Invalid username or password. Attempts left: " + (MAX_ATTEMPTS - loginAttempts));
        }
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    private void openDashboard(String username) {
        try {
            Stage dashboardStage = new Stage();
            VBox dashboard = new VBox(10);
            dashboard.setStyle("-fx-padding: 20; -fx-background-color: #f0f0f0;");

            Label welcomeLabel = new Label("Welcome, " + username);
            welcomeLabel.setStyle("-fx-font-size: 24px; -fx-font-weight: bold;");
            dashboard.getChildren().add(welcomeLabel);

            addClock(dashboard);

            Label titleLabel = new Label("Employee Management Dashboard");
            titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold;");
            dashboard.getChildren().add(titleLabel);

            Button employeesButton = new Button("Manage Employees");
            employeesButton.setOnAction(e -> openEmployeesManagement());

            // Add tooltip
            Tooltip tooltip = new Tooltip("Click here to manage employee records");
            Tooltip.install(employeesButton, tooltip);

            // Add hover effect
            employeesButton.setOnMouseEntered(event -> {
                ScaleTransition scaleUp = new ScaleTransition(Duration.millis(200), employeesButton);
                scaleUp.setToX(1.1);
                scaleUp.setToY(1.1);
                scaleUp.play();
            });

            employeesButton.setOnMouseExited(event -> {
                ScaleTransition scaleDown = new ScaleTransition(Duration.millis(200), employeesButton);
                scaleDown.setToX(1.0);
                scaleDown.setToY(1.0);
                scaleDown.play();
            });

            dashboard.getChildren().add(employeesButton);

            // Logout Button
            Button logoutButton = new Button("Logout");
            logoutButton.setOnAction(e -> {
                dashboardStage.close();
                Stage loginStage = new Stage();
                try {
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("LoginView.fxml"));
                    Parent root = loader.load();
                    Scene scene = new Scene(root);
                    loginStage.setScene(scene);
                    loginStage.setTitle("Factory Employee Management System");
                    loginStage.show();
                } catch (IOException ex) {
                    ex.printStackTrace();
                    showAlert("Error", "Could not open login window.");
                }
            });
            dashboard.getChildren().add(logoutButton);

            // Exit Button
            Button exitButton = new Button("Exit");
            exitButton.setOnAction(e -> {
                dashboardStage.close();
            });
            dashboard.getChildren().add(exitButton);

            Scene scene = new Scene(dashboard, 400, 350);
            dashboardStage.setScene(scene);
            dashboardStage.setTitle("Employee Management Dashboard");

            // Add fade-in effect
            FadeTransition fadeIn = new FadeTransition(Duration.seconds(1), dashboard);
            fadeIn.setFromValue(0);
            fadeIn.setToValue(1);
            fadeIn.play();

            dashboardStage.show();

            Stage loginStage = (Stage) usernameField.getScene().getWindow();
            loginStage.close();

        } catch (Exception e) {
            e.printStackTrace();
            showAlert("Error", "Could not open Dashboard.");
        }
    }

    private void addClock(VBox dashboard) {
        Label clockLabel = new Label();
        clockLabel.setStyle("-fx-font-size: 18px;");

        Timeline clock = new Timeline(new KeyFrame(Duration.seconds(1), event -> {
            clockLabel.setText(java.time.LocalTime.now().format(java.time.format.DateTimeFormatter.ofPattern("HH:mm:ss")));
        }));

        clock.setCycleCount(Timeline.INDEFINITE);
        clock.play();

        dashboard.getChildren().add(clockLabel);
    }

    private void openEmployeesManagement() {
        openWindow("EmployeesView.fxml", "Employees Management");
    }

    private void openWindow(String fxmlFile, String title) {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource(fxmlFile));
            Parent root = loader.load();

            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.setTitle(title);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
            showAlert("Error", "Could not open " + title + " window.");
        }
    }
}
