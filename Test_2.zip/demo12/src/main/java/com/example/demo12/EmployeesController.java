package com.example.demo12;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.time.LocalDate;
import java.util.List;

public class EmployeesController {

    @FXML
    private TextField employeeIdField;
    @FXML
    private TextField firstNameField;
    @FXML
    private TextField lastNameField;
    @FXML
    private TextField emailField;
    @FXML
    private TextField phoneNumberField;
    @FXML
    private TextField jobTitleField;
    @FXML
    private DatePicker hireDatePicker;
    @FXML
    private TableView<Employee> employeesTable;
    @FXML
    private TableColumn<Employee, Integer> idColumn;
    @FXML
    private TableColumn<Employee, String> firstNameColumn;
    @FXML
    private TableColumn<Employee, String> lastNameColumn;
    @FXML
    private TableColumn<Employee, String> emailColumn;
    @FXML
    private TableColumn<Employee, String> phoneColumn;
    @FXML
    private TableColumn<Employee, String> jobTitleColumn;
    @FXML
    private TableColumn<Employee, LocalDate> hireDateColumn;
    @FXML
    private Button viewButton;
    @FXML
    private Button addButton;
    @FXML
    private Button updateButton;
    @FXML
    private Button deleteButton;
    @FXML
    private TextField salaryField;
    @FXML
    private TableColumn<Employee, Double> salaryColumn;
    private ObservableList<Employee> employeesList = FXCollections.observableArrayList();

    private final EmployeeDAO employeeDAO = new EmployeeDAOImpl();

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("employeeId"));
        firstNameColumn.setCellValueFactory(new PropertyValueFactory<>("firstName"));
        lastNameColumn.setCellValueFactory(new PropertyValueFactory<>("lastName"));
        emailColumn.setCellValueFactory(new PropertyValueFactory<>("email"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<>("phoneNumber"));
        jobTitleColumn.setCellValueFactory(new PropertyValueFactory<>("jobTitle"));
        hireDateColumn.setCellValueFactory(new PropertyValueFactory<>("hireDate"));
        salaryColumn.setCellValueFactory(new PropertyValueFactory<>("salary"));
        employeesTable.setItems(employeesList);

        employeesTable.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                employeeIdField.setText(String.valueOf(newSelection.getEmployeeId()));
                firstNameField.setText(newSelection.getFirstName());
                lastNameField.setText(newSelection.getLastName());
                emailField.setText(newSelection.getEmail());
                phoneNumberField.setText(newSelection.getPhoneNumber());
                jobTitleField.setText(newSelection.getJobTitle());
                hireDatePicker.setValue(newSelection.getHireDate());
                salaryField.setText(String.valueOf(newSelection.getSalary()));
            }
        });

        viewButton.setOnAction(event -> viewEmployees());
        addButton.setOnAction(event -> addEmployee());
        updateButton.setOnAction(event -> updateEmployee());
        deleteButton.setOnAction(event -> deleteEmployee());

        loadEmployees();
    }

    @FXML
    private void viewEmployees() {
        loadEmployees();
    }

    @FXML
    private void addEmployee() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String phoneNumber = phoneNumberField.getText();
        String jobTitle = jobTitleField.getText();
        LocalDate hireDate = hireDatePicker.getValue();
        String salaryText = salaryField.getText();
        double salary = 0.0;

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || jobTitle.isEmpty() || hireDate == null || salaryText.isEmpty()) {
            showAlert("Error", "Please fill all required fields.");
            return;
        }

        try {
            salary = Double.parseDouble(salaryText);
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid salary format.");
            return;
        }

        Employee newEmployee = new Employee(0, firstName, lastName, email, phoneNumber, jobTitle, hireDate, salary);
        System.out.println("Attempting to add employee: " + newEmployee);

        try {
            employeeDAO.addEmployee(newEmployee);
            loadEmployees();
            clearFields();
            showAlert("Success", "Employee added successfully.");
        } catch (Exception e) {
            System.out.println("Exception occurred while adding employee: " + e.getMessage());
            e.printStackTrace();
            showAlert("Error", "Failed to add employee. Please check the console for more information.");
        }
    }

    @FXML
    private void updateEmployee() {
        String id = employeeIdField.getText();
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String email = emailField.getText();
        String phoneNumber = phoneNumberField.getText();
        String jobTitle = jobTitleField.getText();
        LocalDate hireDate = hireDatePicker.getValue();
        String salaryText = salaryField.getText();
        double salary = 0.0;


        if (id.isEmpty() || firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || jobTitle.isEmpty() || hireDate == null || salaryText.isEmpty()) {
            showAlert("Error", "Please fill all required fields.");
            return;
        }

        try {
            salary = Double.parseDouble(salaryText);
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid salary format.");
            return;
        }

        try {
            int employeeId = Integer.parseInt(id);
            Employee updatedEmployee = new Employee(employeeId, firstName, lastName, email, phoneNumber, jobTitle, hireDate, salary);
            employeeDAO.updateEmployee(updatedEmployee);
            loadEmployees();
            clearFields();
            showAlert("Success", "Employee updated successfully.");
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid Employee ID.");
        }
    }

    @FXML
    private void deleteEmployee() {
        String id = employeeIdField.getText();

        if (id.isEmpty()) {
            showAlert("Error", "Please select an employee to delete.");
            return;
        }

        try {
            int employeeId = Integer.parseInt(id);
            employeeDAO.deleteEmployee(employeeId);
            loadEmployees();
            clearFields();
            showAlert("Success", "Employee deleted successfully.");
        } catch (NumberFormatException e) {
            showAlert("Error", "Invalid Employee ID.");
        }
    }

    private void loadEmployees() {
        employeesList.clear();
        List<Employee> employees = employeeDAO.getAllEmployees();
        if (employees != null && !employees.isEmpty()) {
            employeesList.addAll(employees);
        } else {
            showAlert("Information", "No employees found in the database.");
        }
    }

    private void clearFields() {
        employeeIdField.clear();
        firstNameField.clear();
        lastNameField.clear();
        emailField.clear();
        phoneNumberField.clear();
        jobTitleField.clear();
        hireDatePicker.setValue(null);
        salaryField.clear();
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}
